import { MarketScanner } from '@/components/market-scanner';

export default function Page() {
  return <MarketScanner />;
}
