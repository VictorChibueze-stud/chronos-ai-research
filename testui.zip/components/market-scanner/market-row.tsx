'use client';

import { cn } from '@/lib/utils';
import type { MarketData } from '@/lib/market-data';
import { TrendScoreRing } from './trend-score-ring';
import { PhaseSteps } from './phase-steps';
import { TimeframeAlignment } from './timeframe-alignment';

interface MarketRowProps {
  data: MarketData;
  isActive?: boolean;
}

export function MarketRow({ data, isActive }: MarketRowProps) {
  const isPositive = data.sessionChange >= 0;
  
  const formatPrice = (price: number) => {
    if (price >= 10000) return price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    if (price >= 100) return price.toFixed(2);
    if (price >= 1) return price.toFixed(4);
    return price.toFixed(5);
  };

  const formatChange = (change: number) => {
    const prefix = change >= 0 ? '+' : '';
    if (Math.abs(change) >= 100) return prefix + change.toFixed(2);
    if (Math.abs(change) >= 1) return prefix + change.toFixed(4);
    return prefix + change.toFixed(5);
  };

  const getAssetClassColor = (assetClass: string) => {
    switch (assetClass) {
      case 'Forex': return 'text-[#3B82F6]';
      case 'Crypto': return 'text-[#8B5CF6]';
      case 'Commodities': return 'text-[#F5A623]';
      case 'Indices': return 'text-[#22C55E]';
      case 'Synthetic Indices': return 'text-[#EC4899]';
      default: return 'text-muted-foreground';
    }
  };

  return (
    <>
      {/* Desktop Row */}
      <div
        className={cn(
          'hidden xl:grid grid-cols-[1fr_100px_80px_80px_90px_140px_120px_130px] items-center gap-2 px-3 py-2 border-b border-border/50 transition-colors hover:bg-muted/30',
          isActive && 'bg-[#F5A623]/10 animate-pulse',
          data.isNewScan && 'ring-1 ring-inset ring-[#F5A623]/30'
        )}
        role="row"
      >
        {/* Symbol & Asset Class */}
        <div className="flex items-center gap-2 min-w-0" role="cell">
          <div className="flex flex-col">
            <span className="font-semibold text-sm text-foreground truncate">{data.symbol}</span>
            <span className={cn('text-[9px] uppercase tracking-wider', getAssetClassColor(data.assetClass))}>
              {data.assetClass}
            </span>
          </div>
          {data.isNewScan && (
            <span className="px-1 py-0.5 text-[8px] font-bold bg-[#F5A623] text-[#0D0F14] rounded-[2px] uppercase">
              New
            </span>
          )}
        </div>

        {/* Trend Direction */}
        <div role="cell">
          <span
            className={cn(
              'px-2 py-0.5 text-[10px] font-bold rounded-[2px] uppercase',
              data.trendDirection === 'LONG'
                ? 'bg-[#22C55E]/20 text-[#22C55E]'
                : 'bg-[#EF4444]/20 text-[#EF4444]'
            )}
          >
            {data.trendDirection}
          </span>
        </div>

        {/* Phase */}
        <div role="cell">
          <span
            className={cn(
              'px-1.5 py-0.5 text-[9px] font-medium rounded-[2px] uppercase',
              data.phase === 'IMPULSE'
                ? 'bg-[#22C55E]/10 text-[#22C55E]'
                : 'bg-[#F5A623]/10 text-[#F5A623]'
            )}
          >
            {data.phase}
          </span>
        </div>

        {/* Trend Score */}
        <div className="flex justify-center" role="cell">
          <TrendScoreRing score={data.trendScore} size={36} />
        </div>

        {/* Phase Steps */}
        <div role="cell">
          <PhaseSteps currentStep={data.phaseStep} phase={data.phase} />
        </div>

        {/* MTF Alignment */}
        <div role="cell">
          <TimeframeAlignment alignedTimeframes={data.alignedTimeframes} />
        </div>

        {/* Break Type */}
        <div role="cell">
          {data.breakType ? (
            <span
              className={cn(
                'px-1.5 py-0.5 text-[9px] font-medium rounded-[2px]',
                data.breakType === 'BOS' && 'bg-[#3B82F6]/20 text-[#3B82F6]',
                data.breakType === 'CHoCH' && 'bg-[#8B5CF6]/20 text-[#8B5CF6]',
                data.breakType === 'True Break' && 'bg-[#22C55E]/20 text-[#22C55E]',
                data.breakType === 'False Break' && 'bg-[#EF4444]/20 text-[#EF4444]'
              )}
            >
              {data.breakType}
            </span>
          ) : (
            <span className="text-[10px] text-muted-foreground/50">—</span>
          )}
        </div>

        {/* Price & Change */}
        <div className="flex flex-col items-end" role="cell">
          <span className="font-semibold text-sm text-foreground tabular-nums">
            {formatPrice(data.price)}
          </span>
          <span
            className={cn(
              'text-[10px] font-medium tabular-nums',
              isPositive ? 'text-[#22C55E]' : 'text-[#EF4444]'
            )}
          >
            {formatChange(data.sessionChange)} ({isPositive ? '+' : ''}{data.sessionChangePercent.toFixed(2)}%)
          </span>
        </div>
      </div>

      {/* Mobile/Tablet Card */}
      <div
        className={cn(
          'xl:hidden p-3 border-b border-border/50 transition-colors hover:bg-muted/30',
          isActive && 'bg-[#F5A623]/10 animate-pulse',
          data.isNewScan && 'ring-1 ring-inset ring-[#F5A623]/30'
        )}
      >
        {/* Top Row: Symbol, Direction, Score */}
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="flex items-center gap-2">
            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-sm text-foreground">{data.symbol}</span>
                {data.isNewScan && (
                  <span className="px-1 py-0.5 text-[8px] font-bold bg-[#F5A623] text-[#0D0F14] rounded-[2px] uppercase">
                    New
                  </span>
                )}
              </div>
              <span className={cn('text-[9px] uppercase tracking-wider', getAssetClassColor(data.assetClass))}>
                {data.assetClass}
              </span>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <TrendScoreRing score={data.trendScore} size={40} />
          </div>
        </div>

        {/* Middle Row: Direction, Phase, Break Type */}
        <div className="flex flex-wrap items-center gap-2 mb-2">
          <span
            className={cn(
              'px-2 py-0.5 text-[10px] font-bold rounded-[2px] uppercase',
              data.trendDirection === 'LONG'
                ? 'bg-[#22C55E]/20 text-[#22C55E]'
                : 'bg-[#EF4444]/20 text-[#EF4444]'
            )}
          >
            {data.trendDirection}
          </span>
          <span
            className={cn(
              'px-1.5 py-0.5 text-[9px] font-medium rounded-[2px] uppercase',
              data.phase === 'IMPULSE'
                ? 'bg-[#22C55E]/10 text-[#22C55E]'
                : 'bg-[#F5A623]/10 text-[#F5A623]'
            )}
          >
            {data.phase}
          </span>
          {data.breakType && (
            <span
              className={cn(
                'px-1.5 py-0.5 text-[9px] font-medium rounded-[2px]',
                data.breakType === 'BOS' && 'bg-[#3B82F6]/20 text-[#3B82F6]',
                data.breakType === 'CHoCH' && 'bg-[#8B5CF6]/20 text-[#8B5CF6]',
                data.breakType === 'True Break' && 'bg-[#22C55E]/20 text-[#22C55E]',
                data.breakType === 'False Break' && 'bg-[#EF4444]/20 text-[#EF4444]'
              )}
            >
              {data.breakType}
            </span>
          )}
        </div>

        {/* Bottom Row: Phase Steps, MTF, Price */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex flex-col gap-1">
            <PhaseSteps currentStep={data.phaseStep} phase={data.phase} />
            <TimeframeAlignment alignedTimeframes={data.alignedTimeframes} />
          </div>
          
          <div className="flex flex-col items-end">
            <span className="font-semibold text-sm text-foreground tabular-nums">
              {formatPrice(data.price)}
            </span>
            <span
              className={cn(
                'text-[10px] font-medium tabular-nums',
                isPositive ? 'text-[#22C55E]' : 'text-[#EF4444]'
              )}
            >
              {isPositive ? '+' : ''}{data.sessionChangePercent.toFixed(2)}%
            </span>
          </div>
        </div>
      </div>
    </>
  );
}
