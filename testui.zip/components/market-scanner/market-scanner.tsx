'use client';

import { useState, useMemo } from 'react';
import { mockMarketData, type AssetClass, type Timeframe } from '@/lib/market-data';
import { Header } from './header';
import { FilterBar } from './filter-bar';
import { MarketTable } from './market-table';
import { StatusBar } from './status-bar';

export function MarketScanner() {
  const [selectedAssetClass, setSelectedAssetClass] = useState<AssetClass | 'All'>('All');
  const [selectedTimeframes, setSelectedTimeframes] = useState<Timeframe[]>(['W1', 'D1', 'H4', 'H1', 'M15']);
  const [sortBy, setSortBy] = useState<'trendScore' | 'symbol' | 'sessionChange'>('trendScore');

  const handleTimeframeToggle = (tf: Timeframe) => {
    setSelectedTimeframes((prev) =>
      prev.includes(tf) ? prev.filter((t) => t !== tf) : [...prev, tf]
    );
  };

  const filteredAndSortedData = useMemo(() => {
    let data = [...mockMarketData];

    // Filter by asset class
    if (selectedAssetClass !== 'All') {
      data = data.filter((m) => m.assetClass === selectedAssetClass);
    }

    // Filter by timeframe alignment (must have at least one selected timeframe aligned)
    if (selectedTimeframes.length > 0) {
      data = data.filter((m) =>
        selectedTimeframes.some((tf) => m.alignedTimeframes.includes(tf))
      );
    }

    // Sort
    switch (sortBy) {
      case 'trendScore':
        data.sort((a, b) => b.trendScore - a.trendScore);
        break;
      case 'symbol':
        data.sort((a, b) => a.symbol.localeCompare(b.symbol));
        break;
      case 'sessionChange':
        data.sort((a, b) => Math.abs(b.sessionChangePercent) - Math.abs(a.sessionChangePercent));
        break;
    }

    return data;
  }, [selectedAssetClass, selectedTimeframes, sortBy]);

  return (
    <div className="flex flex-col h-screen bg-background">
      <Header />
      
      <FilterBar
        selectedAssetClass={selectedAssetClass}
        onAssetClassChange={setSelectedAssetClass}
        selectedTimeframes={selectedTimeframes}
        onTimeframeToggle={handleTimeframeToggle}
        sortBy={sortBy}
        onSortChange={setSortBy}
        totalMarkets={mockMarketData.length}
        filteredCount={filteredAndSortedData.length}
      />

      <main className="flex-1 overflow-hidden" role="main">
        <MarketTable data={filteredAndSortedData} />
      </main>

      <StatusBar />
    </div>
  );
}
