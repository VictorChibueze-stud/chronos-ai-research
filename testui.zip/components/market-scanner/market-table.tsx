'use client';

import type { MarketData } from '@/lib/market-data';
import { MarketRow } from './market-row';
import { ScrollArea } from '@/components/ui/scroll-area';

interface MarketTableProps {
  data: MarketData[];
}

export function MarketTable({ data }: MarketTableProps) {
  return (
    <div className="flex flex-col h-full">
      {/* Desktop Header */}
      <div 
        className="hidden xl:grid grid-cols-[1fr_100px_80px_80px_90px_140px_120px_130px] items-center gap-2 px-3 py-2 bg-muted/30 border-b border-border text-[10px] uppercase tracking-wider text-muted-foreground font-medium sticky top-0 z-10"
        role="row"
        aria-label="Table header"
      >
        <div role="columnheader">Symbol</div>
        <div role="columnheader">Direction</div>
        <div role="columnheader">Phase</div>
        <div role="columnheader" className="text-center">Score</div>
        <div role="columnheader">Phase Step</div>
        <div role="columnheader">MTF Alignment</div>
        <div role="columnheader">Structure</div>
        <div role="columnheader" className="text-right">Price</div>
      </div>

      {/* Mobile Header */}
      <div className="xl:hidden px-3 py-2 bg-muted/30 border-b border-border text-[10px] uppercase tracking-wider text-muted-foreground font-medium sticky top-0 z-10">
        {data.length} Markets
      </div>

      {/* Rows */}
      <ScrollArea className="flex-1">
        <div role="rowgroup">
          {data.length === 0 ? (
            <div className="flex items-center justify-center py-12 text-muted-foreground text-sm">
              No markets match your filters
            </div>
          ) : (
            data.map((market) => (
              <MarketRow 
                key={market.id} 
                data={market}
                isActive={market.isNewScan}
              />
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
