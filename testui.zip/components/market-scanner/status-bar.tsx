'use client';

import { useEffect, useState } from 'react';

export function StatusBar() {
  const [time, setTime] = useState<string>('');
  
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString('en-US', { 
        hour12: false, 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit' 
      }));
    };
    
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <footer className="flex items-center justify-between px-4 py-2 border-t border-border bg-card text-[10px] text-muted-foreground">
      <div className="flex items-center gap-4">
        <span className="uppercase tracking-wider">
          Proprietary Trend Detection Algorithm
        </span>
        <span className="hidden sm:inline">|</span>
        <span className="hidden sm:inline">
          Multi-timeframe Analysis
        </span>
      </div>
      
      <div className="flex items-center gap-4">
        <span className="tabular-nums">{time} UTC</span>
        <span className="hidden sm:flex items-center gap-1">
          <span className="relative flex h-1.5 w-1.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#22C55E] opacity-75" />
            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-[#22C55E]" />
          </span>
          LIVE
        </span>
      </div>
    </footer>
  );
}
