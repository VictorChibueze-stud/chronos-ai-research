'use client';

import { cn } from '@/lib/utils';

interface TrendScoreRingProps {
  score: number;
  size?: number;
  className?: string;
}

export function TrendScoreRing({ score, size = 40, className }: TrendScoreRingProps) {
  const strokeWidth = 3;
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (score / 100) * circumference;
  
  const getScoreColor = (score: number) => {
    if (score >= 80) return '#22C55E'; // Green - strong
    if (score >= 60) return '#F5A623'; // Amber - moderate
    return '#EF4444'; // Red - weak
  };

  const color = getScoreColor(score);

  return (
    <div className={cn('relative inline-flex items-center justify-center', className)}>
      <svg
        width={size}
        height={size}
        className="-rotate-90"
        aria-label={`Trend Score: ${score}`}
      >
        {/* Background circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeWidth={strokeWidth}
          className="text-muted/30"
        />
        {/* Progress circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className="transition-all duration-500 ease-out"
        />
      </svg>
      <span 
        className="absolute text-[10px] font-semibold"
        style={{ color }}
      >
        {score}
      </span>
    </div>
  );
}
