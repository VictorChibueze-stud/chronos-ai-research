'use client';

import { cn } from '@/lib/utils';

interface LivePulseProps {
  className?: string;
}

export function LivePulse({ className }: LivePulseProps) {
  return (
    <span className={cn('relative flex h-2 w-2', className)}>
      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#22C55E] opacity-75" />
      <span className="relative inline-flex rounded-full h-2 w-2 bg-[#22C55E]" />
    </span>
  );
}
