'use client';

import { cn } from '@/lib/utils';
import type { Timeframe } from '@/lib/market-data';

interface TimeframeAlignmentProps {
  alignedTimeframes: Timeframe[];
  allTimeframes?: Timeframe[];
  className?: string;
}

export function TimeframeAlignment({ 
  alignedTimeframes, 
  allTimeframes = ['W1', 'D1', 'H4', 'H1', 'M15'],
  className 
}: TimeframeAlignmentProps) {
  return (
    <div className={cn('flex items-center gap-1', className)} aria-label={`Aligned timeframes: ${alignedTimeframes.join(', ')}`}>
      {allTimeframes.map((tf) => {
        const isAligned = alignedTimeframes.includes(tf);
        
        return (
          <span
            key={tf}
            className={cn(
              'px-1 py-0.5 text-[9px] font-medium rounded-[2px] transition-colors',
              isAligned
                ? 'bg-[#F5A623]/20 text-[#F5A623]'
                : 'bg-muted/50 text-muted-foreground/40'
            )}
          >
            {tf}
          </span>
        );
      })}
    </div>
  );
}
