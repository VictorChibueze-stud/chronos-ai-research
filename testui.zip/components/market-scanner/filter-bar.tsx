'use client';

import { cn } from '@/lib/utils';
import { assetClasses, type AssetClass, type Timeframe, timeframes } from '@/lib/market-data';
import { LivePulse } from './live-pulse';

interface FilterBarProps {
  selectedAssetClass: AssetClass | 'All';
  onAssetClassChange: (assetClass: AssetClass | 'All') => void;
  selectedTimeframes: Timeframe[];
  onTimeframeToggle: (tf: Timeframe) => void;
  sortBy: 'trendScore' | 'symbol' | 'sessionChange';
  onSortChange: (sort: 'trendScore' | 'symbol' | 'sessionChange') => void;
  totalMarkets: number;
  filteredCount: number;
}

export function FilterBar({
  selectedAssetClass,
  onAssetClassChange,
  selectedTimeframes,
  onTimeframeToggle,
  sortBy,
  onSortChange,
  totalMarkets,
  filteredCount,
}: FilterBarProps) {
  return (
    <div className="flex flex-col gap-3 p-3 border-b border-border bg-card">
      {/* Top row - Asset class filters */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <LivePulse />
          <span className="text-[11px] text-muted-foreground uppercase tracking-wider">
            Market Scanner
          </span>
          <span className="text-[10px] text-muted-foreground">
            {filteredCount}/{totalMarkets}
          </span>
        </div>
        
        <div className="flex flex-wrap items-center gap-1">
          <button
            onClick={() => onAssetClassChange('All')}
            className={cn(
              'px-2 py-1 text-[10px] font-medium rounded-[2px] transition-colors uppercase tracking-wide',
              selectedAssetClass === 'All'
                ? 'bg-[#F5A623] text-[#0D0F14]'
                : 'bg-muted/50 text-muted-foreground hover:bg-muted'
            )}
            aria-pressed={selectedAssetClass === 'All'}
          >
            All
          </button>
          {assetClasses.map((ac) => (
            <button
              key={ac}
              onClick={() => onAssetClassChange(ac)}
              className={cn(
                'px-2 py-1 text-[10px] font-medium rounded-[2px] transition-colors uppercase tracking-wide',
                selectedAssetClass === ac
                  ? 'bg-[#F5A623] text-[#0D0F14]'
                  : 'bg-muted/50 text-muted-foreground hover:bg-muted'
              )}
              aria-pressed={selectedAssetClass === ac}
            >
              {ac}
            </button>
          ))}
        </div>
      </div>

      {/* Bottom row - Timeframe toggles and sort */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-muted-foreground uppercase tracking-wider">
            MTF Alignment:
          </span>
          <div className="flex items-center gap-1">
            {timeframes.map((tf) => (
              <button
                key={tf}
                onClick={() => onTimeframeToggle(tf)}
                className={cn(
                  'px-1.5 py-0.5 text-[10px] font-medium rounded-[2px] transition-colors',
                  selectedTimeframes.includes(tf)
                    ? 'bg-[#F5A623]/20 text-[#F5A623] ring-1 ring-[#F5A623]/50'
                    : 'bg-muted/50 text-muted-foreground hover:bg-muted'
                )}
                aria-pressed={selectedTimeframes.includes(tf)}
                aria-label={`Toggle ${tf} timeframe`}
              >
                {tf}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] text-muted-foreground uppercase tracking-wider">
            Sort:
          </span>
          <select
            value={sortBy}
            onChange={(e) => onSortChange(e.target.value as typeof sortBy)}
            className="bg-muted/50 text-[10px] px-2 py-1 rounded-[2px] border-none focus:ring-1 focus:ring-[#F5A623] text-foreground"
            aria-label="Sort markets by"
          >
            <option value="trendScore">Trend Score</option>
            <option value="symbol">Symbol</option>
            <option value="sessionChange">Session %</option>
          </select>
        </div>
      </div>
    </div>
  );
}
