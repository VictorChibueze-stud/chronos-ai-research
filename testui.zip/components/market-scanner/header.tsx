'use client';

import { useTheme } from 'next-themes';
import { cn } from '@/lib/utils';
import { Sun, Moon, Activity } from 'lucide-react';

export function Header() {
  const { theme, setTheme } = useTheme();
  
  return (
    <header className="flex items-center justify-between px-4 py-3 border-b border-border bg-card">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <Activity className="h-5 w-5 text-[#F5A623]" />
          <span className="text-lg font-bold tracking-tight text-foreground">
            CHRONOS<span className="text-[#F5A623]">AI</span>
          </span>
        </div>
        <div className="hidden sm:flex items-center gap-1 px-2 py-0.5 bg-muted/50 rounded-[2px]">
          <span className="text-[10px] text-muted-foreground uppercase tracking-wider">
            Market Scanner
          </span>
          <span className="text-[9px] text-[#F5A623]">v2.4</span>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* System Status */}
        <div className="hidden md:flex items-center gap-2 px-2 py-1 bg-muted/30 rounded-[2px]">
          <span className="relative flex h-1.5 w-1.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#22C55E] opacity-75" />
            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-[#22C55E]" />
          </span>
          <span className="text-[10px] text-muted-foreground">
            ALGO ACTIVE
          </span>
        </div>

        {/* Theme Toggle */}
        <button
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          className={cn(
            'flex items-center gap-1 px-2 py-1 rounded-[2px] transition-colors',
            'bg-muted/50 hover:bg-muted text-muted-foreground hover:text-foreground'
          )}
          aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
        >
          {theme === 'dark' ? (
            <>
              <Sun className="h-3.5 w-3.5" />
              <span className="text-[10px] uppercase tracking-wider hidden sm:inline">Light</span>
            </>
          ) : (
            <>
              <Moon className="h-3.5 w-3.5" />
              <span className="text-[10px] uppercase tracking-wider hidden sm:inline">Dark</span>
            </>
          )}
        </button>
      </div>
    </header>
  );
}
