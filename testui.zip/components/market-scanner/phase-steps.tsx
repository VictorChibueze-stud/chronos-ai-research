'use client';

import { cn } from '@/lib/utils';
import type { Phase } from '@/lib/market-data';

interface PhaseStepsProps {
  currentStep: number;
  totalSteps?: number;
  phase: Phase;
  className?: string;
}

export function PhaseSteps({ currentStep, totalSteps = 5, phase, className }: PhaseStepsProps) {
  const isImpulse = phase === 'IMPULSE';
  
  return (
    <div className={cn('flex items-center gap-0.5', className)} aria-label={`Phase Step ${currentStep} of ${totalSteps}`}>
      {Array.from({ length: totalSteps }, (_, i) => {
        const stepNumber = i + 1;
        const isActive = stepNumber <= currentStep;
        
        return (
          <div
            key={stepNumber}
            className={cn(
              'h-3 w-1.5 rounded-[1px] transition-colors',
              isActive
                ? isImpulse 
                  ? 'bg-[#22C55E]' 
                  : 'bg-[#F5A623]'
                : 'bg-muted-foreground/20'
            )}
            aria-hidden="true"
          />
        );
      })}
      <span className="ml-1.5 text-[10px] text-muted-foreground">
        {currentStep}/{totalSteps}
      </span>
    </div>
  );
}
